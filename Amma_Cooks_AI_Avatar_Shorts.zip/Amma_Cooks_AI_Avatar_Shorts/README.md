# Amma Cooks — AI Telugu Avatar Shorts Creator

This upgraded project is designed around your actual goal: **one Telugu YouTube Short per day with a consistent Amma-style talking avatar**.

## Pipeline

**Telugu recipe → Telugu TTS → talking/lip-synced avatar → cooking visuals → captions/music → 1080×1920 MP4**

### What is included
- Streamlit creator UI
- Telugu Piper TTS voices: Maya, Padmavathi, Venkatesh
- Avatar-photo input
- SadTalker integration for audio-driven talking face
- Optional cooking clips/photos
- Optional background music
- Vertical Shorts output workflow
- Windows/Linux launcher scripts

## Why the avatar engine is not bundled
The lip-sync model checkpoints are large ML files and should be downloaded separately. Bundling them would make this ZIP unnecessarily huge and can also create license/version issues. The setup script prepares the SadTalker repository; follow its official checkpoint download instructions before the first avatar generation.

## Windows

1. Install **Python 3.11** (recommended for compatibility with older ML stacks).
2. Install **Git**.
3. Install **FFmpeg** and ensure `ffmpeg -version` works in Command Prompt.
4. Double-click `run_windows.bat`.
5. Open the local Streamlit page.
6. Upload a front-facing avatar image.
7. Paste Telugu script.
8. Choose Telugu voice.
9. Run `setup_sadtalker_windows.bat` once and install/download SadTalker checkpoints as described by SadTalker.
10. Create the Short.

## Linux

```bash
chmod +x run_linux.sh setup_sadtalker_linux.sh
./run_linux.sh
./setup_sadtalker_linux.sh
```

## Hardware reality
For practical daily use, a CUDA/NVIDIA GPU is strongly recommended for talking-avatar generation. A CPU can work for some stages but may be very slow. If your laptop has no suitable GPU, keep the TTS locally and run the lip-sync stage on a free/temporary GPU environment such as a personal Google Colab notebook, subject to that service's current limits.

## Telugu voice licensing
Piper documents Telugu (`te_IN`) voices and notes that each voice's MODEL_CARD contains its licensing information. Review the exact voice license before monetizing a channel.

## Avatar safety
Use an avatar you created yourself, an AI-generated fictional character, or a person's likeness only with permission. Do not impersonate a real person without consent.

## Recommended Amma Cooks Short format
- 0–4 sec: avatar greeting/hook
- 4–40 sec: close-up cooking footage + Telugu narration
- 40–52 sec: avatar conclusion/tip
- 52–60 sec: “ఇలాంటి మరిన్ని వంటకాల కోసం ఫాలో చేయండి”

For realism, **do not make the avatar pretend to perform every cooking action**. Keep the avatar as the narrator and use real/generated close-ups for chopping, stirring, boiling, serving, etc. This generally looks much more natural.
