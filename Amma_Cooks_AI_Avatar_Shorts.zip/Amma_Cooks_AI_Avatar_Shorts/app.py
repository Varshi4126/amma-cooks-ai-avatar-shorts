import os, re, subprocess, sys, urllib.request, shutil
from pathlib import Path
import streamlit as st

ROOT = Path(__file__).parent
OUT = ROOT/'outputs'; OUT.mkdir(exist_ok=True)
MODELS = ROOT/'models'; MODELS.mkdir(exist_ok=True)
ASSETS = ROOT/'assets'; ASSETS.mkdir(exist_ok=True)

st.set_page_config(page_title='Amma Cooks AI Avatar Shorts', page_icon='👩‍🍳', layout='wide')

st.title('👩‍🍳 Amma Cooks — AI Telugu Shorts Creator')
st.caption('Telugu script → Telugu voice → talking avatar → cooking visuals → captions → 1080×1920 Short')

with st.sidebar:
    st.header('Avatar')
    avatar = st.file_uploader('Upload your Amma avatar photo', type=['png','jpg','jpeg'])
    st.caption('Use a front-facing, well-lit face with the mouth visible. You can use an AI-generated character or a person who has given permission.')
    st.divider()
    st.header('Telugu Voice')
    voice = st.selectbox('Voice', ['Maya (female)', 'Padmavathi (female)', 'Venkatesh (male)'])
    st.divider()
    st.header('Cooking visuals')
    cooking = st.file_uploader('Optional cooking photos/video clips', type=['png','jpg','jpeg','mp4','mov','webm'], accept_multiple_files=True)
    music = st.file_uploader('Optional background music', type=['mp3','wav','m4a'])

script = st.text_area('Paste your Telugu recipe/script', height=260, placeholder='నమస్కారం అందరికీ... ఇవాళ మనం చాలా రుచికరమైన పరమాన్నం ఎలా చేయాలో చూద్దాం...')
title = st.text_input('Short title', 'అమ్మ చేతి పరమాన్నం ❤️')

st.subheader('Recommended Short structure')
st.code('0–4s  Avatar intro\n4–40s Cooking close-ups + narration\n40–55s Avatar conclusion\n55–60s Follow/subscribe CTA')

col1, col2, col3 = st.columns(3)
with col1: duration = st.slider('Target duration (seconds)', 20, 60, 45)
with col2: caption_size = st.slider('Caption size', 28, 64, 44)
with col3: avatar_seconds = st.slider('Avatar section (seconds)', 4, 15, 7)


def download_piper(voice):
    names = {'Maya (female)':'maya','Padmavathi (female)':'padmavathi','Venkatesh (male)':'venkatesh'}
    n = names[voice]
    model = MODELS/f'te_IN-{n}-medium.onnx'
    cfg = MODELS/f'te_IN-{n}-medium.onnx.json'
    base = f'https://huggingface.co/rhasspy/piper-voices/resolve/main/te/te_IN/{n}/medium/'
    if not model.exists(): urllib.request.urlretrieve(base+model.name+'?download=true', model)
    if not cfg.exists(): urllib.request.urlretrieve(base+cfg.name+'?download=true', cfg)
    return model, cfg

def tts(text, voice, wav):
    model, cfg = download_piper(voice)
    # Piper CLI is installed by requirements.
    p = subprocess.run([sys.executable, '-m', 'piper', '-m', str(model), '--config', str(cfg), '--output_file', str(wav)], input=text.encode('utf-8'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.decode(errors='ignore'))

def find_sadtalker():
    candidates = [ROOT/'SadTalker', ROOT/'sadtalker', Path(os.environ.get('SADTALKER_HOME',''))]
    for c in candidates:
        if c and (c/'inference.py').exists(): return c
    return None

def make_talking_avatar(avatar_path, wav, outdir):
    repo = find_sadtalker()
    if not repo:
        raise FileNotFoundError('SadTalker is not installed. Run setup_sadtalker_windows.bat or setup_sadtalker_linux.sh first.')
    outdir.mkdir(exist_ok=True)
    cmd = [sys.executable, 'inference.py', '--driven_audio', str(wav), '--source_image', str(avatar_path), '--result_dir', str(outdir), '--preprocess', 'full', '--still']
    subprocess.run(cmd, cwd=repo, check=True)
    mp4s = sorted(outdir.glob('*.mp4'), key=lambda p:p.stat().st_mtime, reverse=True)
    if not mp4s: raise RuntimeError('SadTalker finished but no MP4 was found.')
    return mp4s[0]

def build_fallback_video(script, title, wav, out):
    # A useful fallback if the avatar engine is not installed: narrated vertical recipe card video.
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg: raise RuntimeError('FFmpeg is required.')
    srt = OUT/'captions.srt'
    # approximate caption timing
    chunks = [x.strip() for x in re.split(r'\n\s*\n+', script) if x.strip()]
    if not chunks: chunks=[script]
    per=max(2, duration/max(1,len(chunks)))
    with open(srt,'w',encoding='utf-8') as f:
        for i,c in enumerate(chunks,1):
            a=i-1; b=i
            f.write(f'{i}\n00:00:{int(a*per):02d},000 --> 00:00:{int(b*per):02d},000\n{c}\n\n')
    # simple black vertical background; user can still validate voice/script pipeline.
    subprocess.run([ffmpeg,'-y','-f','lavfi','-i','color=c=black:s=1080x1920:r=30','-i',str(wav),'-t',str(duration),'-vf',f"subtitles={srt.as_posix()}:force_style='FontSize={caption_size},Alignment=2,MarginV=180'",'-c:v','libx264','-c:a','aac','-shortest',str(out)],check=True)

if st.button('🎬 CREATE MY AMMA COOKS SHORT', type='primary', use_container_width=True):
    if not script.strip(): st.error('Please paste a Telugu script.'); st.stop()
    if not avatar:
        st.warning('Upload an avatar photo. The full talking-avatar pipeline needs a face image.')
        st.stop()
    avatar_path=OUT/'avatar.png'; avatar_path.write_bytes(avatar.getbuffer())
    wav=OUT/'telugu_voice.wav'
    with st.status('Creating your Short...', expanded=True) as status:
        st.write('🗣️ Generating Telugu narration...')
        try: tts(script, voice, wav)
        except Exception as e:
            status.update(label='TTS failed', state='error'); st.exception(e); st.stop()
        st.write('👄 Generating lip-synced avatar...')
        try:
            avatar_video=make_talking_avatar(avatar_path,wav,OUT/'avatar_result')
            st.video(str(avatar_video))
            status.update(label='Avatar generated. Cooking assembly is next.', state='complete')
            st.success('Lip-synced avatar created successfully.')
            st.info('Use the included render_short.py to combine the avatar, cooking clips, captions and music into the final 1080×1920 Short.')
        except Exception as e:
            status.update(label='Avatar engine not installed', state='error')
            st.error(str(e))
            st.info('The project is ready; run the one-time SadTalker setup script included in the ZIP, then create the Short again.')

st.divider()
st.markdown('### Free/local design')
st.markdown('Piper provides Telugu `te_IN` voices. SadTalker provides audio-driven single-image talking-face animation. Both can be run locally; model downloads are one-time and depend on your computer/GPU. Check the individual model licenses before commercial use.')
