"""Command-line assembly helper.

Usage example:
python render_short.py --avatar outputs/avatar_result/*.mp4 --cooking assets/cooking.mp4 --audio outputs/telugu_voice.wav --out outputs/final_short.mp4

Requires ffmpeg on PATH.
"""
import argparse, subprocess, shutil
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--avatar',required=True); p.add_argument('--audio',required=True); p.add_argument('--out',required=True); p.add_argument('--cooking'); p.add_argument('--music'); args=p.parse_args()
ff=shutil.which('ffmpeg')
if not ff: raise SystemExit('FFmpeg not found. Install FFmpeg and put it on PATH.')
# Keep the first production version simple and reliable: avatar video fills the Short frame.
cmd=[ff,'-y','-i',args.avatar]
if args.music: cmd += ['-i',args.music]
cmd += ['-vf','scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2','-r','30','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',args.out]
subprocess.run(cmd,check=True)
print('Created:',args.out)
