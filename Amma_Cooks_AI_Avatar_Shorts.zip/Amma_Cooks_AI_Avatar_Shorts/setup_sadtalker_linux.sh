#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -d SadTalker ]; then git clone https://github.com/OpenTalker/SadTalker.git; fi
cd SadTalker
python3 -m pip install -r requirements.txt
printf '\nSadTalker dependencies installed. Download its checkpoints using the official instructions before first use.\n'
