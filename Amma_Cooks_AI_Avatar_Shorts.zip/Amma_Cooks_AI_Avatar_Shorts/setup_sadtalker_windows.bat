@echo off
setlocal
cd /d %~dp0
if not exist SadTalker (
  echo Cloning SadTalker...
  git clone https://github.com/OpenTalker/SadTalker.git
)
cd SadTalker
python -m pip install -r requirements.txt
python -c "import os; print('SadTalker dependencies installed. Download checkpoints using the official SadTalker instructions/launcher before first use.')"
pause
